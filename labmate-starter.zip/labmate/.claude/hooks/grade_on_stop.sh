#!/usr/bin/env bash
# Stop hook. When the agent believes it's finished, grade the active study against
# docs/rubric.json so "done" is verifiable without a human. Prints the verdict.
#
# This calls the grader script in scripts/. If no study id is set, it just reminds.
# Never blocks the stop (exit 0); it's a verification + reminder.

set -euo pipefail

study_id="${LABMATE_STUDY_ID:-}"

if [ -z "$study_id" ]; then
  echo "[grade_on_stop] No LABMATE_STUDY_ID set — skipping rubric grade. Set it to auto-verify done."
  exit 0
fi

if [ -f scripts/grade_study.py ]; then
  echo "[grade_on_stop] Grading study $study_id against docs/rubric.json ..."
  python3 scripts/grade_study.py --study "$study_id" --rubric docs/rubric.json || true
else
  echo "[grade_on_stop] scripts/grade_study.py not found yet. Implement it to grade against docs/rubric.json."
fi

exit 0
