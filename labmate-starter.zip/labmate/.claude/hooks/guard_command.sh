#!/usr/bin/env bash
# PreToolUse hook for Bash. Reads the tool input JSON on stdin, decides whether to allow.
# Exit 0 = allow. Exit 2 (with JSON {"decision":"block","reason":...}) = block.
#
# Enforces CLAUDE.md hard rules #2 and #3:
#   - no destructive commands without approval
#   - Modal compute launches must have a recorded approval and stay within budget
#
# This is a STARTER hook. Wire the approval/budget check to your control plane
# (apps/web) once query endpoints exist; until then it pattern-matches the command.

set -euo pipefail
input="$(cat)"
cmd="$(printf '%s' "$input" | python3 -c 'import sys,json; print(json.load(sys.stdin).get("tool_input",{}).get("command",""))' 2>/dev/null || echo "")"

block() {
  printf '{"decision":"block","reason":%s}\n' "$(python3 -c 'import json,sys; print(json.dumps(sys.argv[1]))' "$1")"
  exit 2
}

# 1. Destructive commands — hard block.
case "$cmd" in
  *"rm -rf"*|*"DROP TABLE"*|*"DROP DATABASE"*|*"r2 object delete"*|*"git push --force"*)
    block "Destructive command blocked by Labmate guard. A human must run this explicitly." ;;
esac

# 2. Modal launches — require a recorded approval token in the env/ledger.
#    Replace this stub with a real check against your control plane.
case "$cmd" in
  *"modal run"*|*"modal deploy"*|*"launch_experiment"*)
    if [ "${LABMATE_LAUNCH_APPROVED:-0}" != "1" ]; then
      block "Compute launch requires human approval. Approve the experiment in the cockpit (sets LABMATE_LAUNCH_APPROVED=1) before launching."
    fi
    ;;
esac

# Allow everything else.
exit 0
