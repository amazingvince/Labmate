#!/usr/bin/env bash
# PostToolUse hook for Bash. Appends run metadata to a local evidence ledger so every
# experiment launch is captured even outside the main conversation. Mirrors what the
# MCP server records in D1; this local copy is handy for the session log / demo.
#
# Reads tool input+output JSON on stdin. Never blocks (always exit 0).

set -euo pipefail
input="$(cat)"
ledger=".claude/ledger.jsonl"

# Only log when the command looks like an experiment launch.
cmd="$(printf '%s' "$input" | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("tool_input",{}).get("command",""))' 2>/dev/null || echo "")"
case "$cmd" in
  *"launch_experiment"*|*"modal run"*|*"run-study.js"*)
    ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf '%s' "$input" | python3 -c '
import sys, json, os
ts = os.environ.get("LM_TS", "")
try:
    d = json.load(sys.stdin)
except Exception:
    d = {}
rec = {
    "ts": ts,
    "command": d.get("tool_input", {}).get("command", ""),
    "exit": d.get("tool_response", {}).get("exit_code"),
    "note": "experiment launch captured by log_run hook",
}
print(json.dumps(rec))
' LM_TS="$ts" >> "$ledger" 2>/dev/null || true
    ;;
esac

exit 0
