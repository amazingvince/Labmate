#!/usr/bin/env node
/**
 * run-study.js — Labmate dynamic workflow (orchestration spine).
 *
 * Drives the scientific loop end to end by delegating to subagents and the
 * Labmate MCP tools:
 *
 *   profile -> plan -> [HUMAN CHECKPOINT] -> run -> critique -> rerun -> report -> grade
 *
 * This is a STARTER. The phases below are wired as functions with clear TODOs.
 * Each phase delegates to a subagent (.claude/agents) and/or calls an MCP tool
 * (apps/mcp-server). Intermediate results are written to .claude/state/<study>.json
 * so they live OUTSIDE the main conversation (long-horizon state stays intact).
 *
 * Usage:
 *   node .claude/workflows/run-study.js <dataset_dir>
 *   e.g. node .claude/workflows/run-study.js examples/sla_tickets
 *
 * The human approval checkpoint is real: the workflow pauses and waits for an
 * approval to be recorded (via the cockpit / record_human_feedback) before any
 * compute launches. Do not auto-approve.
 */

import fs from "node:fs";
import path from "node:path";

const datasetDir = process.argv[2] || "examples/sla_tickets";
const STATE_DIR = ".claude/state";

function loadState(studyId) {
  const p = path.join(STATE_DIR, `${studyId}.json`);
  return fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, "utf8")) : {};
}
function saveState(studyId, state) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  fs.writeFileSync(path.join(STATE_DIR, `${studyId}.json`), JSON.stringify(state, null, 2));
}

/**
 * Phase 1 — Brief + profile.
 * Delegate to: ds-planner subagent.
 * MCP: create_study(brief, dataset_id, target, metric, constraints, budget),
 *      profile_dataset(study_id).
 * Output: data contract written; study_id returned.
 */
async function phaseProfile() {
  // TODO: read datasetDir/brief.md + rubric.md, call create_study, then profile_dataset.
  // Apply leakage-review during profiling; default leakage candidates to banned.
  throw new Error("TODO: implement phaseProfile — call create_study + profile_dataset via MCP, invoke ds-planner.");
}

/**
 * Phase 2 — Plan.
 * Delegate to: ds-planner.
 * MCP: propose_experiments(study_id, n=5..8).
 * Output: hypothesis cards (each with hypothesis, rationale, model family, features, cost).
 */
async function phasePlan(studyId) {
  // TODO: invoke ds-planner to propose 5-8 hypothesis cards; persist them to state.
  throw new Error("TODO: implement phasePlan — propose_experiments + ds-planner.");
}

/**
 * Phase 3 — HUMAN CHECKPOINT (blocking).
 * The human approves/edits/rejects cards and may add natural-language guidance,
 * which the cockpit parses into structured constraints. The workflow waits here.
 * MCP: request_approval(study_id, experiment_ids, reason, estimated_cost),
 *      record_human_feedback(study_id, target_id, feedback).
 */
async function phaseHumanCheckpoint(studyId) {
  // TODO: call request_approval, then poll until an approval (and any feedback)
  // is recorded. Set LABMATE_LAUNCH_APPROVED=1 only after a real approval.
  // Do NOT auto-approve — the gate is the safety story.
  throw new Error("TODO: implement phaseHumanCheckpoint — request_approval + wait for human.");
}

/**
 * Phase 4 — Run (can fan out concurrently).
 * Delegate to: experiment-runner (one per approved card; run in parallel branches).
 * MCP: launch_experiment(study_id, manifest), query_runs(study_id, filters).
 * Each run logs metrics, params, artifacts, rationale, hypothesis_id, provenance.
 */
async function phaseRun(studyId) {
  // TODO: for each approved card, build a manifest and launch_experiment on Modal.
  // Apply optuna-search for tuned cards. Confirm via query_runs.
  throw new Error("TODO: implement phaseRun — experiment-runner + launch_experiment (parallel).");
}

/**
 * Phase 5 — Critique + rerun.
 * Delegate to: experiment-critic, then experiment-runner for corrections.
 * Catches leakage / test-set tuning / metric misuse; emits critiques + decisions.
 * The corrected experiment is rerun (the demo's headline moment).
 */
async function phaseCritique(studyId) {
  // TODO: invoke experiment-critic over all runs; for any kind in [leakage, test_set_tuning]
  // with a fixable error, build a corrected manifest and rerun via experiment-runner.
  throw new Error("TODO: implement phaseCritique — experiment-critic + corrective rerun.");
}

/**
 * Phase 6 — Report.
 * Delegate to: report-writer.
 * MCP: write_report(study_id, report_type='model_card').
 * Produces the model card artifact with best-vs-baseline + provenance footer.
 */
async function phaseReport(studyId) {
  // TODO: invoke report-writer; store report artifact in R2 via write_report.
  throw new Error("TODO: implement phaseReport — report-writer + write_report.");
}

/**
 * Phase 7 — Grade (verifiable done).
 * MCP: grade_study_against_rubric(study_id) against docs/rubric.json.
 * Prints pass/fail per required check, including caught_an_issue.
 */
async function phaseGrade(studyId) {
  // TODO: call grade_study_against_rubric; print verdict. Non-zero exit if any
  // required check fails so CI / the Stop hook can detect "not done".
  throw new Error("TODO: implement phaseGrade — grade_study_against_rubric vs docs/rubric.json.");
}

async function main() {
  console.log(`Labmate run-study on dataset: ${datasetDir}`);
  // The skeleton below shows the intended sequence. Implement each phase, then
  // thread the study_id and state through.
  const study = await phaseProfile();
  const studyId = study.id;
  saveState(studyId, { ...loadState(studyId), phase: "profiled", study });

  await phasePlan(studyId);
  await phaseHumanCheckpoint(studyId); // blocks until human approves
  await phaseRun(studyId);
  await phaseCritique(studyId);        // catches + reruns
  await phaseReport(studyId);
  const verdict = await phaseGrade(studyId);

  console.log("Study complete. Rubric verdict:", verdict);
}

main().catch((err) => {
  console.error("\n[run-study] Stopped:", err.message);
  console.error("Implement the TODO for the phase above, then rerun.");
  process.exit(1);
});
