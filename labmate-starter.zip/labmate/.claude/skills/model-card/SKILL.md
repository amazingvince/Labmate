---
name: model-card
description: Produce a reproducible model card / final report for a Labmate study. Use whenever writing the study's final report or documenting a promoted model. Enforces a fixed structure (objective, data, split, experiments, best vs baseline, critiques, human feedback, risks, next steps, reproducible command) and a provenance footer. Apply this for any "generate report" request.
---

# Model card

A model card a stranger can read and reproduce. Pull every number from the evidence ledger;
never invent values.

## Structure

```markdown
# Model card: <study title>

## Objective
- Business goal: ...
- Primary metric: <metric> (rationale: ...)
- Guardrails: <e.g. false_positive_rate <= 0.20>

## Data
- Source: ...
- Rows: ...
- Prediction time: ...
- Leakage candidates and handling: <columns> — excluded / approved because ...

## Split
- Strategy: <time-based / stratified> · Seed: <n>
- Train / validation / test sizes: ...

## Experiments
| Hypothesis | Model | Features | Primary metric | Guardrail met? | Status |
|---|---|---|---|---|---|
| ... | ... | ... | ... | yes/no | promoted/rejected/rerun |

## Best result vs baseline
- Baseline: <metric value>
- Promoted model: <metric value>  (lift: <delta>)
- Why it should be trusted: ...

## Critiques incorporated
- <e.g. "Run X tuned the threshold on the test split; rerun on validation.">

## Human feedback incorporated
- <constraint> -> <how it changed the plan>

## Risks & caveats
- Calibration, segment performance (e.g. enterprise tier), generalization limits.

## Next steps
- Rejected-but-promising ideas; what to try next.

## Reproduce
```bash
<exact command to retrain the promoted model with the recorded seed>
```

---
Provenance: dataset_hash=<...> · code_hash=<...> · seed=<...> · generated=<timestamp>
```

## Hard rules
- MUST include the best-vs-baseline comparison and the provenance footer (the rubric checks
  both: `compares_best_to_baseline` and `dataset_hash/code_hash/seed`).
- If nothing beat baseline meaningfully, say so plainly and recommend stopping.
- Keep claims tied to ledger evidence.
