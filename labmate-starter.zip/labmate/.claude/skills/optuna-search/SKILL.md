---
name: optuna-search
description: Run a small, safe hyperparameter search with Optuna for tabular models. Use whenever an experiment card calls for tuning a tree model (random forest, HistGradientBoosting, XGBoost/LightGBM). Enforces small search spaces, capped trials, TPE sampling, pruning, validation-only tuning, and trial-level logging. Apply this whenever tuning is involved so searches stay cheap and methodologically clean.
---

# Optuna search

Keep searches small, cheap, and honest. The point is a defensible improvement, not a
leaderboard grind.

## Rules

1. **Tune on validation, never test.** The objective function evaluates on the validation
   split. The test split is untouched until final evaluation.
2. **Small search spaces.** A handful of impactful params, sensible ranges. Examples:
   - RandomForest: `n_estimators` [100, 600], `max_depth` [3, 20], `min_samples_leaf` [1, 20],
     `class_weight` in {None, balanced}.
   - HistGradientBoosting: `learning_rate` [0.01, 0.3] (log), `max_leaf_nodes` [15, 255],
     `l2_regularization` [1e-6, 1.0] (log), `max_iter` [100, 500].
3. **Cap trials.** Default `LABMATE_DEFAULT_MAX_TRIALS` (20) unless the human raises it.
   Respect the time budget (`LABMATE_DEFAULT_BUDGET_SECONDS`).
4. **TPE by default.** Use `optuna.samplers.TPESampler(seed=42)`.
5. **Prune** unpromising trials when the model supports it (e.g. `MedianPruner`).
6. **Log trial-level params and metrics** back to the tracker, and the best params on the run.
7. **Seed everything** (sampler, model, split) for reproducibility.

## Objective skeleton (validation-only)

```python
def objective(trial):
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 100, 600),
        "max_depth": trial.suggest_int("max_depth", 3, 20),
        "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 20),
        "class_weight": trial.suggest_categorical("class_weight", [None, "balanced"]),
        "random_state": 42,
    }
    model = RandomForestClassifier(**params).fit(X_train, y_train)
    # primary metric on VALIDATION, guardrail enforced
    return recall_at_fpr(y_val, model.predict_proba(X_val)[:, 1], max_fpr=0.20)

study = optuna.create_study(direction="maximize",
                            sampler=optuna.samplers.TPESampler(seed=42),
                            pruner=optuna.pruners.MedianPruner())
study.optimize(objective, n_trials=MAX_TRIALS, timeout=BUDGET_SECONDS)
```

## Anti-patterns
- Searching on the test split (this is the planted critic-catch — never do it; the critic
  will reject it).
- Unbounded trials or no timeout.
- Tuning the decision threshold on test.
