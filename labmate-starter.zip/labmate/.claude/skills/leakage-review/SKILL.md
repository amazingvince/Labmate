---
name: leakage-review
description: Detect data leakage in tabular ML before training. Use whenever profiling a dataset, proposing features, or reviewing a run — and ALWAYS before training any tuned model. Scans column names for post-outcome signals, checks timestamp ordering, verifies feature availability at prediction time, and requires explicit human approval for suspicious features. Apply this even when not asked; leakage is the most common reason a great score is meaningless.
---

# Leakage review

Leakage = using information at training time that would not be available at prediction time.
It produces models that look excellent and fail in production. Catching it is a headline
capability of Labmate.

## What to check

1. **Post-outcome column names.** Flag anything whose value is only known after the outcome:
   names containing `resolved`, `closed`, `final`, `outcome`, `label`, `target`,
   `time_to_*`, `*_at_close`, `disposition`, `settled`, `actual_*`. In the demo dataset:
   `resolved_at`, `time_to_resolution`, `closed_status`, `agent_notes_final`.
2. **Timestamp ordering.** For any datetime feature, confirm it occurs at or before the
   prediction time. A feature timestamped after `created_at` (the prediction moment) is
   leakage.
3. **Feature availability at prediction time.** For each candidate feature, ask: "would this
   value exist at the instant we make the prediction?" If no → leakage.
4. **Target-derived features.** Anything computed from the target (or from fields that
   encode the outcome) leaks.
5. **Train/test contamination.** Preprocessing (scaling, encoding, imputation) fit on the
   full dataset instead of train-only leaks test information into training.
6. **Duplicate / near-duplicate rows** spanning the split.

## Procedure

- Produce a list of `leakage_candidates` with the reason for each.
- Default leakage candidates to **banned** in the data contract.
- If a candidate might be legitimate (e.g. a slow-changing attribute), require **explicit
  human approval** (`record_human_feedback` reversing the ban) before it can be used.
- Re-run this review when the feature set changes.

## Output
Write a critique `kind = 'leakage'` listing the offending columns and the recommendation.
When a run used a banned/leaky column, recommend `reject` or `rerun` with it removed.

## In the demo
The `sla_tickets` dataset intentionally contains post-outcome columns. You are expected to
catch them at profiling time and recommend exclusion — this is planted moment #1.
