---
name: tabular-ds-protocol
description: The non-negotiable protocol for any tabular ML experiment in Labmate. Use whenever profiling data, proposing experiments, or running a model on a CSV/tabular business dataset. Enforces a deterministic split before feature engineering, a baseline before tuned models, documented target+metric, a leakage check, comparison against baseline, and a model card. Apply this even if the user just says "train a model" — the protocol always comes first.
---

# Tabular DS protocol

A disciplined order of operations. Follow it every time; skipping a step produces a number
nobody should trust.

## The protocol (in order)

1. **Establish the semantic contract first.** Before any modeling, fix the target definition,
   the prediction time, and the metric (+ guardrails). Write them into the data and metric
   contracts. Never "just train."
2. **Create a deterministic split before feature engineering.** Choose the split strategy
   (time-based when there's an ordering; stratified random otherwise), fix a seed, and record
   both. Feature engineering happens *after* the split, fit on train only.
3. **Train a baseline first.** A `DummyClassifier`/`DummyRegressor` and a simple
   logistic/linear model. Every later model is judged against these.
4. **Run a leakage check.** Apply the `leakage-review` skill before training anything tuned.
   Banned columns stay out unless a human explicitly approves them.
5. **Compare against baseline.** Report lift over baseline on the primary metric, with the
   guardrail respected. Lift within noise is not a win.
6. **Tune on validation, evaluate test once.** Hyperparameters and thresholds are selected on
   the validation split. The test split is touched a single time, at the end.
7. **Produce a model card.** Apply the `model-card` skill. No card → not done.

## Logging requirements
- Log the target definition and metric rationale on the study.
- Log every run's hypothesis_id, rationale, params, metrics, artifacts, seed, dataset hash,
  and code hash.
- Record every decision (promote/reject/rerun/branch/stop) with a reason.

## Anti-patterns to refuse
- Random shuffling a time-ordered dataset.
- Fitting preprocessing on the full dataset before splitting.
- Reporting accuracy on an imbalanced target.
- Selecting a threshold on the test split.
- Promoting a threshold-tuned model with no calibration check.
